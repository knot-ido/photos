树洞外链
============
树洞外链是一款免费开源的PHP外链网盘系统，界面简洁友好，支持七牛、本地、远程、阿里云OSS、又拍云五种储存方式，支持多用户系统，多上传方案策略。
### 截图
![树洞外链-免费高速外链平台.png](https://o2d7sesam.qnssl.com/树洞外链-免费高速外链平台.png)
![文件详情 - 树洞外链.png](https://o2d7sesam.qnssl.com/文件详情 - 树洞外链.png)
![个人详情 - 树洞外链.png](https://o2d7sesam.qnssl.com/个人详情 - 树洞外链.png)
### 快捷导航
- 主页：http://yun.aoaoao.me/
- 帮助文档：http://yun.aoaoao.me/help.php
- 演示站：http://yun.aoaoao.me/demo/
- Telegram讨论组：https://t.me/joinchat/AAAAAAjY3eZJeKX3Kwfptw

### 安装
未安装时自动跳转至install目录进行安装
### 环境要求
PHP版本>=5.3且启用Mysqlnd MySQL>=5.1
### 许可证
GPL V3