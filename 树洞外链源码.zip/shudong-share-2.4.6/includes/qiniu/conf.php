<?php
global $SDK_VER;

global $QINIU_UP_HOST;
global $QINIU_RS_HOST;
global $QINIU_RSF_HOST;
global $QINIU_API_HOST;
global $QINIU_IOVIP_HOST;

global $QINIU_ACCESS_KEY;
global $QINIU_SECRET_KEY;

$SDK_VER = "6.1.13";

$QINIU_UP_HOST	= 'http://upload.qiniu.com';
$QINIU_RS_HOST	= 'http://rs.qbox.me';
$QINIU_RSF_HOST	= 'http://rsf.qbox.me';
$QINIU_API_HOST = 'http://api.qiniu.com';
$QINIU_IOVIP_HOST = 'http://iovip.qbox.me';

$QINIU_ACCESS_KEY	= '<Please apply your access key>';
$QINIU_SECRET_KEY	= '<Dont send your secret key to anyone>';
